| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2880.0/128.0 | 28.9 |
| image-pull-auth | image_pull_auth | 0/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2945.0/91.0 | 21.7 |
| oom-killed | oom_killed | 0/1 | 0/1 | 1/3 (33.3%) | 0/3 (0.0%) | 1/3 (33.3%) | 0 | 0 | 4.0 | 4353.0/89.0 | 21.0 |
| pending-node-selector | node_selector_mismatch | 0/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2896.0/54.0 | 18.9 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2929.0/94.0 | 21.7 |
| stuck-rollout | stuck_rollout_bad_image | 0/1 | 0/1 | 2/4 (50.0%) | 2/4 (50.0%) | 2/4 (50.0%) | 0 | 0 | 5.0 | 5045.0/115.0 | 22.1 |
