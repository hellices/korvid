| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2893.0/165.0 | 88.3 |
| image-pull-auth | image_pull_auth | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2978.0/149.0 | 72.0 |
| oom-killed | oom_killed | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2929.0/140.0 | 68.7 |
| pending-node-selector | node_selector_mismatch | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2919.0/80.0 | 60.4 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 0/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2956.0/66.0 | 59.2 |
| stuck-rollout | stuck_rollout_bad_image | 0/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 3133.0/131.0 | 73.4 |
