| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4135.0/605.0 | 46.8 |
| image-pull-auth | image_pull_auth | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4213.0/715.0 | 40.6 |
| oom-killed | oom_killed | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4164.0/920.0 | 50.8 |
| pending-node-selector | node_selector_mismatch | 1/1 | 1/1 | 2/2 (100.0%) | 2/2 (100.0%) | 0/2 (0.0%) | 0 | 0 | 3.0 | 6570.0/1277.0 | 71.9 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4194.0/1002.0 | 55.3 |
| stuck-rollout | stuck_rollout_bad_image | 0/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4351.0/760.0 | 44.5 |
