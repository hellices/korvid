| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | ~0.0/0.0 | 60.5 |
| image-pull-auth | image_pull_auth | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | ~0.0/0.0 | 60.0 |
| oom-killed | oom_killed | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | ~0.0/0.0 | 60.0 |
| pending-node-selector | node_selector_mismatch | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2896.0/118.0 | 83.0 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | ~0.0/0.0 | 60.0 |
| stuck-rollout | stuck_rollout_bad_image | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | ~0.0/0.0 | 60.0 |
