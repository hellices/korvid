| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 5503.0/163.0 | 32.4 |
| image-pull-auth | image_pull_auth | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 5581.0/263.0 | 18.8 |
| oom-killed | oom_killed | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 5532.0/238.0 | 17.4 |
| pending-node-selector | node_selector_mismatch | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 5517.0/173.0 | 13.7 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 5562.0/216.0 | 16.3 |
| stuck-rollout | stuck_rollout_bad_image | 1/1 | 1/1 | 1/2 (50.0%) | 1/2 (50.0%) | 0/2 (0.0%) | 0 | 0 | 3.0 | 8529.0/268.0 | 22.3 |
