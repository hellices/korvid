| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 1/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1867.0/28.0 | 12.0 |
| image-pull-auth | image_pull_auth | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1859.0/22.0 | 1.6 |
| oom-killed | oom_killed | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1855.0/126.0 | 6.1 |
| pending-node-selector | node_selector_mismatch | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1868.0/130.0 | 6.3 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1860.0/369.0 | 16.8 |
| stuck-rollout | stuck_rollout_bad_image | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1864.0/62.0 | 3.4 |
