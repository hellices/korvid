| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 638.0/239.0 | 22.5 |
| image-pull-auth | image_pull_auth | 1/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 630.0/130.0 | 9.3 |
| oom-killed | oom_killed | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 627.0/310.0 | 21.4 |
| pending-node-selector | node_selector_mismatch | 1/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 639.0/790.0 | 54.5 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 631.0/353.0 | 24.4 |
| stuck-rollout | stuck_rollout_bad_image | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 635.0/254.0 | 17.7 |
