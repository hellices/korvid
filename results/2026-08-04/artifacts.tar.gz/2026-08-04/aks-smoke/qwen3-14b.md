| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4135.0/667.0 | 114.1 |
| image-pull-auth | image_pull_auth | 0/1 | 0/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4095.0/931.0 | 112.0 |
| oom-killed | oom_killed | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4164.0/924.0 | 112.9 |
| pending-node-selector | node_selector_mismatch | 0/1 | 1/1 | 2/2 (100.0%) | 2/2 (100.0%) | 0/2 (0.0%) | 0 | 0 | 3.0 | 6189.0/1271.0 | 153.0 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 1/1 | 0/1 | 4/4 (100.0%) | 3/4 (75.0%) | 0/4 (0.0%) | 0 | 0 | 5.0 | 10371.0/2192.0 | 259.6 |
| stuck-rollout | stuck_rollout_bad_image | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4351.0/769.0 | 99.3 |
