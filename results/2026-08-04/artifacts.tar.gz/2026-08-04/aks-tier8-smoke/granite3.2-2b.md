| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 1/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1950.0/477.0 | 23.8 |
| image-pull-auth | image_pull_auth | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1942.0/378.0 | 11.5 |
| oom-killed | oom_killed | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1938.0/312.0 | 9.5 |
| pending-node-selector | node_selector_mismatch | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1952.0/443.0 | 13.7 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1944.0/572.0 | 17.6 |
| stuck-rollout | stuck_rollout_bad_image | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1948.0/262.0 | 8.2 |
