| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 0/1 | 0/1 | 0/1 (0.0%) | 0/1 (0.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2712.0/117.0 | 6.7 |
| image-pull-auth | image_pull_auth | 0/1 | 0/1 | 0/1 (0.0%) | 0/1 (0.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2680.0/143.0 | 6.1 |
| oom-killed | oom_killed | 0/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2899.0/317.0 | 10.4 |
| pending-node-selector | node_selector_mismatch | 0/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2892.0/180.0 | 7.2 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1960.0/82.0 | 4.3 |
| stuck-rollout | stuck_rollout_bad_image | 0/1 | 0/1 | 0/1 (0.0%) | 0/1 (0.0%) | 1/1 (100.0%) | 0 | 0 | 2.0 | 2684.0/91.0 | 2.6 |
