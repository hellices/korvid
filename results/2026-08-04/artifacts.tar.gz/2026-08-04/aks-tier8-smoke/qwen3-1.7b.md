| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4135.0/634.0 | 22.0 |
| image-pull-auth | image_pull_auth | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4213.0/610.0 | 18.7 |
| oom-killed | oom_killed | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4164.0/740.0 | 22.6 |
| pending-node-selector | node_selector_mismatch | 0/1 | 1/1 | 1/2 (50.0%) | 1/2 (50.0%) | 0/2 (0.0%) | 0 | 0 | 3.0 | 6402.0/1362.0 | 38.5 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 1/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4194.0/630.0 | 18.7 |
| stuck-rollout | stuck_rollout_bad_image | 0/1 | 1/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 4351.0/770.0 | 22.8 |
