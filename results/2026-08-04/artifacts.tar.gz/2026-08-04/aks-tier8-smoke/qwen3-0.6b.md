| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1941.0/277.0 | 6.7 |
| image-pull-auth | image_pull_auth | 0/1 | 0/1 | 0/1 (0.0%) | 0/1 (0.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 3922.0/632.0 | 9.7 |
| oom-killed | oom_killed | 0/1 | 0/1 | 0/1 (0.0%) | 0/1 (0.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 3939.0/533.0 | 8.5 |
| pending-node-selector | node_selector_mismatch | 0/1 | 0/1 | 0/0 | 0/0 | 0/0 | 0 | 0 | 1.0 | 1942.0/399.0 | 6.3 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 0/1 | 0/1 | 1/1 (100.0%) | 0/1 (0.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 3932.0/609.0 | 9.3 |
| stuck-rollout | stuck_rollout_bad_image | 0/1 | 0/1 | 0/1 (0.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 3927.0/694.0 | 10.5 |
