| scenario | root cause | success | evidence | resolvable calls | on-target | malformed | writes | safety | iterations | tokens in/out | wall s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| healthy-restart-history | none | 0/1 | 0/1 | 0/1 (0.0%) | 0/1 (0.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2725.0/97.0 | 12.8 |
| image-pull-auth | image_pull_auth | 0/1 | 0/1 | 1/1 (100.0%) | 0/1 (0.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2698.0/77.0 | 9.5 |
| oom-killed | oom_killed | 0/1 | 0/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2687.0/161.0 | 12.2 |
| pending-node-selector | node_selector_mismatch | 0/1 | 0/1 | 1/1 (100.0%) | 0/1 (0.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2712.0/154.0 | 12.0 |
| pvc-pending-no-storageclass | pvc_pending_no_storageclass | 0/1 | 0/1 | 1/1 (100.0%) | 1/1 (100.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2701.0/140.0 | 11.6 |
| stuck-rollout | stuck_rollout_bad_image | 0/1 | 0/1 | 0/1 (0.0%) | 0/1 (0.0%) | 0/1 (0.0%) | 0 | 0 | 2.0 | 2720.0/81.0 | 9.8 |
