| journey | success | turns | malformed | stale targets | wall s |
|---|---:|---:|---:|---:|---:|
| healthy-stop | 1/3 | 6 | 2 | 0 | 81.4 |
| logs-to-events | 1/3 | 6 | 1 | 0 | 131.1 |
| triage-and-correct | 1/3 | 9 | 0 | 0 | 161.6 |
