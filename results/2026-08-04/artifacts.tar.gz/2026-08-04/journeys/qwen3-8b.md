| journey | success | turns | malformed | stale targets | wall s |
|---|---:|---:|---:|---:|---:|
| healthy-stop | 3/3 | 6 | 0 | 0 | 282.5 |
| logs-to-events | 1/3 | 6 | 0 | 0 | 389.7 |
| triage-and-correct | 2/3 | 9 | 0 | 0 | 787.2 |
