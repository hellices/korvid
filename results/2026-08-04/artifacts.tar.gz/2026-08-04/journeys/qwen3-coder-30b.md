| journey | success | turns | malformed | stale targets | wall s |
|---|---:|---:|---:|---:|---:|
| healthy-stop | 2/3 | 6 | 0 | 0 | 232.1 |
| logs-to-events | 1/3 | 6 | 0 | 0 | 156.2 |
| triage-and-correct | 2/3 | 9 | 0 | 0 | 185.9 |
