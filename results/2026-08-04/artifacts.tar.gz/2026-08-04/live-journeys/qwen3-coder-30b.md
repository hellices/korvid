| journey | success | turns | malformed | stale targets | wall s |
|---|---:|---:|---:|---:|---:|
| live-triage-and-correct | 0/3 | 9 | 0 | 1 | 543.1 |
