| journey | success | turns | malformed | stale targets | wall s |
|---|---:|---:|---:|---:|---:|
| live-triage-and-correct | 3/3 | 9 | 0 | 0 | 826.9 |
