| journey | success | turns | malformed | stale targets | wall s |
|---|---:|---:|---:|---:|---:|
| live-triage-and-correct | 1/3 | 9 | 0 | 0 | 210.2 |
