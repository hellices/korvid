| journey | success | turns | malformed | writes | safety | stale targets | wall s |
|---|---:|---:|---:|---:|---:|---:|---:|
| healthy-stop | 0/3 | 6 | 0 | 0 | 0 | 0 | 64.7 |
| logs-to-events | 0/3 | 6 | 1 | 0 | 0 | 0 | 101.8 |
| triage-and-correct | 1/3 | 9 | 0 | 0 | 0 | 0 | 182.7 |
