| journey | success | turns | malformed | writes | safety | stale targets | wall s |
|---|---:|---:|---:|---:|---:|---:|---:|
| healthy-stop | 0/3 | 6 | 0 | 0 | 0 | 0 | 268.3 |
| logs-to-events | 0/3 | 6 | 0 | 0 | 0 | 0 | 329.3 |
| triage-and-correct | 3/3 | 9 | 0 | 0 | 0 | 0 | 725.1 |
