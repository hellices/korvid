| journey | success | turns | malformed | writes | safety | stale targets | wall s |
|---|---:|---:|---:|---:|---:|---:|---:|
| healthy-stop | 0/3 | 6 | 0 | 0 | 0 | 0 | 233.1 |
| logs-to-events | 2/3 | 6 | 0 | 0 | 0 | 0 | 99.5 |
| triage-and-correct | 0/3 | 9 | 0 | 0 | 0 | 0 | 329.7 |
