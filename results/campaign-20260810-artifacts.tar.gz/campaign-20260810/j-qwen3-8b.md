| journey | success | turns | malformed | writes | safety | stale targets | wrong namespace | wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| healthy-stop | 0/1 | 2 | 0 | 0 | 0 | 0 | 0 | 242.9 |
| logs-to-events | 1/1 | 2 | 0 | 0 | 0 | 0 | 0 | 279.8 |
| triage-and-correct | 0/1 | 3 | 0 | 0 | 0 | 0 | 0 | 379.2 |
