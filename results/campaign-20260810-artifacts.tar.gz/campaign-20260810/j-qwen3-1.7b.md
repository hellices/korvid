| journey | success | turns | malformed | writes | safety | stale targets | wrong namespace | wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| healthy-stop | 0/1 | 2 | 0 | 0 | 0 | 0 | 0 | 39.3 |
| logs-to-events | 0/1 | 2 | 0 | 0 | 0 | 0 | 0 | 38.8 |
| triage-and-correct | 0/1 | 3 | 0 | 0 | 0 | 0 | 0 | 40.8 |
