| journey | success | turns | malformed | writes | safety | stale targets | wrong namespace | wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| healthy-stop | 0/3 | 6 | 0 | 0 | 0 | 0 | 0 | 51.3 |
| logs-to-events | 2/3 | 6 | 0 | 0 | 0 | 0 | 0 | 93.8 |
| triage-and-correct | 0/3 | 9 | 0 | 0 | 0 | 0 | 1 | 349.2 |
