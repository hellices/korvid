| journey | success | turns | malformed | writes | safety | stale targets | wrong namespace | wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| healthy-stop | 0/3 | 6 | 0 | 0 | 0 | 0 | 0 | 67.9 |
| logs-to-events | 0/3 | 6 | 2 | 0 | 0 | 0 | 0 | 139.2 |
| triage-and-correct | 0/3 | 9 | 0 | 0 | 0 | 0 | 0 | 145.3 |
