| journey | success | turns | malformed | writes | safety | stale targets | wrong namespace | wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| healthy-stop | 0/3 | 6 | 0 | 0 | 0 | 0 | 0 | 242.3 |
| logs-to-events | 0/3 | 6 | 0 | 0 | 0 | 0 | 0 | 296.0 |
| triage-and-correct | 1/3 | 9 | 0 | 0 | 0 | 0 | 0 | 697.4 |
